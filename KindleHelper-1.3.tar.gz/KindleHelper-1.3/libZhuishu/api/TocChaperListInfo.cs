﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace libZhuishu
{
    public class TocChaperListInfo
    {
        public string _id;
        public string name;
        public string link;
        public tocChaperInfo[] chapters;
        public string updated;
    }
}
