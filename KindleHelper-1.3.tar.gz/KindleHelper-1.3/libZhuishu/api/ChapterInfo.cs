﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace libZhuishu
{
    public class ChapterInfo
    {
        public string title;
        public string body;
        public bool isVip;
        public string cpContent;
        public int currency;
        public string id;
    }
}
