﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace libZhuishu
{
    public class TocSummmaryInfo
    {
        public string _id;
        public string lastChapter;
        public string link;
        public string aeasou;
        public string name;
        public bool isCharge;
        public int chaptersCount;
        public string updated;
        public bool starting;
        public string host;
    }
}
