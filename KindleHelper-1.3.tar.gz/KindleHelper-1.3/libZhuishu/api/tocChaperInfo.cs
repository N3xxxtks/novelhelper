﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace libZhuishu
{
    public class tocChaperInfo
    {
        public string title;
        public string link;
        public bool unreadble;
        public string id;
        public int currency;
        public bool isVip;
    }
}
