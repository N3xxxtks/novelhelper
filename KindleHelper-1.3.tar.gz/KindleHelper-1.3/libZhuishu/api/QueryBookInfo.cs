﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace libZhuishu
{
    public class QueryBookInfo
    {
        public string _id;
        public bool hasCp;
        public string title;
        public string cat;
        public string author;
        public string site;
        public string cover;
        public string shortIntro;
        public string lastChapter;
        public string retentionRatio;
        public int latelyFollower;
        public long wordCount;
    }
}
